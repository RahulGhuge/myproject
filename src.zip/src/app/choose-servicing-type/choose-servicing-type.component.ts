import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-choose-servicing-type',
  templateUrl: './choose-servicing-type.component.html',
  styleUrls: ['./choose-servicing-type.component.css']
})
export class ChooseServicingTypeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
