import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-servicing-type',
  templateUrl: './servicing-type.component.html',
  styleUrls: ['./servicing-type.component.css']
})
export class ServicingTypeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
